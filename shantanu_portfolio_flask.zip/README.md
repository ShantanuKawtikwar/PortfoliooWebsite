# Shantanu Portfolio Flask App

This is a Flask-based portfolio web app with:

- Hero landing page (pastel sky-blue & beige theme)
- Timeline, Skills, Projects, Certifications, Contact
- Admin panel to manage Projects, Certifications and Timeline
- Image upload support for projects & certifications
- Interactive contact form (sends email via SMTP)

## Structure

- app.py              → main Flask app
- models.py           → SQLAlchemy models
- admin_setup.py      → script to create the first admin user
- templates/          → Jinja2 templates (HTML)
- static/uploads/     → uploaded images
- requirements.txt
- Procfile

## Local Setup

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### Environment variables (recommended)

Set these before running:

- `SECRET_KEY`       – any random secret (for sessions)
- `MAIL_USERNAME`    – your Gmail address
- `MAIL_PASSWORD`    – your app password (not normal Gmail password)

### Initialize the database

```bash
flask --app app init-db
python admin_setup.py
```

This will:

- Create `database.db`
- Create admin user:

    - Username: `Shantanukawtikwar27`
    - Password: `Prachi2711@$`

### Run locally

```bash
flask --app app run
```

Open: http://127.0.0.1:5000/

- Public site: `/`
- Contact form: `/contact`
- Admin login: `/admin/login`

## Deploy (Render example)

- Create a new Web Service on Render
- Connect GitHub repo
- Use:

  - Build command: `pip install -r requirements.txt`
  - Start command: `gunicorn app:app`

- Set environment variables in Render dashboard:

  - `SECRET_KEY`
  - `MAIL_USERNAME`
  - `MAIL_PASSWORD`

Done 🎉
