import os
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mail import Mail, Message
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from models import db, AdminUser, Project, Certification, Timeline

app = Flask(__name__)

# ===== Config =====
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Uploads
UPLOAD_FOLDER = os.path.join('static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Mail (use environment variables in production)
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', 'your_email@gmail.com')
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', 'your_app_password')

mail = Mail(app)
db.init_app(app)


# ===== Helpers =====

def admin_required():
    if not session.get('admin_id'):
        return False
    return True


# ===== Public Routes =====

@app.route('/')
def home():
    projects = Project.query.order_by(Project.id.desc()).all()
    certs = Certification.query.order_by(Certification.id.desc()).all()
    timeline = Timeline.query.order_by(Timeline.id.asc()).all()
    return render_template('index.html', projects=projects, certs=certs, timeline=timeline)


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message_text = request.form.get('message')

        msg = Message(
            subject=f'Portfolio message from {name}',
            sender=email,
            recipients=[app.config['MAIL_USERNAME']],
            body=f'From: {name} <{email}>\n\n{message_text}'
        )
        try:
            mail.send(msg)
            flash('Message sent successfully! ✅', 'success')
        except Exception as e:
            print('MAIL ERROR:', e)
            flash('Failed to send message. Please try again later.', 'danger')

        return redirect(url_for('contact'))

    return render_template('contact.html')


# ===== Admin Auth =====

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = AdminUser.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            session['admin_id'] = user.id
            flash('Logged in successfully ✅', 'success')
            return redirect(url_for('admin_dashboard'))
        flash('Invalid username or password', 'danger')
    return render_template('admin_login.html')


@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_id', None)
    flash('Logged out', 'info')
    return redirect(url_for('admin_login'))


# ===== Admin Dashboard =====

@app.route('/admin/dashboard')
def admin_dashboard():
    if not admin_required():
        return redirect(url_for('admin_login'))

    projects = Project.query.order_by(Project.id.desc()).all()
    certs = Certification.query.order_by(Certification.id.desc()).all()
    timeline = Timeline.query.order_by(Timeline.id.asc()).all()
    return render_template('admin_dashboard.html',
                           projects=projects,
                           certs=certs,
                           timeline=timeline)


# ===== CRUD Helpers =====

def save_image(file_storage):
    if not file_storage or file_storage.filename == '':
        return None
    filename = secure_filename(file_storage.filename)
    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file_storage.save(path)
    return filename


# --- Projects ---

@app.route('/admin/project/add', methods=['GET', 'POST'])
def add_project():
    if not admin_required():
        return redirect(url_for('admin_login'))
    if request.method == 'POST':
        title = request.form.get('title')
        desc = request.form.get('description')
        date = request.form.get('date')
        image_file = request.files.get('image')
        img_name = save_image(image_file)

        proj = Project(title=title, description=desc, date=date, image=img_name)
        db.session.add(proj)
        db.session.commit()
        flash('Project added ✅', 'success')
        return redirect(url_for('admin_dashboard'))
    return render_template('admin_form.html', mode='project', item=None)


@app.route('/admin/project/edit/<int:item_id>', methods=['GET', 'POST'])
def edit_project(item_id):
    if not admin_required():
        return redirect(url_for('admin_login'))
    proj = Project.query.get_or_404(item_id)
    if request.method == 'POST':
        proj.title = request.form.get('title')
        proj.description = request.form.get('description')
        proj.date = request.form.get('date')
        image_file = request.files.get('image')
        if image_file and image_file.filename:
            img_name = save_image(image_file)
            proj.image = img_name
        db.session.commit()
        flash('Project updated ✅', 'success')
        return redirect(url_for('admin_dashboard'))
    return render_template('admin_form.html', mode='project', item=proj)


@app.route('/admin/project/delete/<int:item_id>', methods=['GET', 'POST'])
def delete_project(item_id):
    if not admin_required():
        return redirect(url_for('admin_login'))
    proj = Project.query.get_or_404(item_id)
    if request.method == 'POST':
        db.session.delete(proj)
        db.session.commit()
        flash('Project deleted 🗑️', 'info')
        return redirect(url_for('admin_dashboard'))
    return render_template('confirm_delete.html', mode='project', item=proj)


# --- Certifications ---

@app.route('/admin/cert/add', methods=['GET', 'POST'])
def add_cert():
    if not admin_required():
        return redirect(url_for('admin_login'))
    if request.method == 'POST':
        title = request.form.get('title')
        issuer = request.form.get('issuer')
        date = request.form.get('date')
        image_file = request.files.get('image')
        img_name = save_image(image_file)
        cert = Certification(title=title, issuer=issuer, date=date, image=img_name)
        db.session.add(cert)
        db.session.commit()
        flash('Certification added ✅', 'success')
        return redirect(url_for('admin_dashboard'))
    return render_template('admin_form.html', mode='cert', item=None)


@app.route('/admin/cert/edit/<int:item_id>', methods=['GET', 'POST'])
def edit_cert(item_id):
    if not admin_required():
        return redirect(url_for('admin_login'))
    cert = Certification.query.get_or_404(item_id)
    if request.method == 'POST':
        cert.title = request.form.get('title')
        cert.issuer = request.form.get('issuer')
        cert.date = request.form.get('date')
        image_file = request.files.get('image')
        if image_file and image_file.filename:
            img_name = save_image(image_file)
            cert.image = img_name
        db.session.commit()
        flash('Certification updated ✅', 'success')
        return redirect(url_for('admin_dashboard'))
    return render_template('admin_form.html', mode='cert', item=cert)


@app.route('/admin/cert/delete/<int:item_id>', methods=['GET', 'POST'])
def delete_cert(item_id):
    if not admin_required():
        return redirect(url_for('admin_login'))
    cert = Certification.query.get_or_404(item_id)
    if request.method == 'POST':
        db.session.delete(cert)
        db.session.commit()
        flash('Certification deleted 🗑️', 'info')
        return redirect(url_for('admin_dashboard'))
    return render_template('confirm_delete.html', mode='cert', item=cert)


# --- Timeline ---

@app.route('/admin/timeline/add', methods=['GET', 'POST'])
def add_timeline():
    if not admin_required():
        return redirect(url_for('admin_login'))
    if request.method == 'POST':
        month = request.form.get('month')
        title = request.form.get('title')
        org = request.form.get('organization')
        details = request.form.get('details')
        t = Timeline(month=month, title=title, organization=org, details=details)
        db.session.add(t)
        db.session.commit()
        flash('Timeline entry added ✅', 'success')
        return redirect(url_for('admin_dashboard'))
    return render_template('admin_form.html', mode='timeline', item=None)


@app.route('/admin/timeline/edit/<int:item_id>', methods=['GET', 'POST'])
def edit_timeline(item_id):
    if not admin_required():
        return redirect(url_for('admin_login'))
    t = Timeline.query.get_or_404(item_id)
    if request.method == 'POST':
        t.month = request.form.get('month')
        t.title = request.form.get('title')
        t.organization = request.form.get('organization')
        t.details = request.form.get('details')
        db.session.commit()
        flash('Timeline updated ✅', 'success')
        return redirect(url_for('admin_dashboard'))
    return render_template('admin_form.html', mode='timeline', item=t)


@app.route('/admin/timeline/delete/<int:item_id>', methods=['GET', 'POST'])
def delete_timeline(item_id):
    if not admin_required():
        return redirect(url_for('admin_login'))
    t = Timeline.query.get_or_404(item_id)
    if request.method == 'POST':
        db.session.delete(t)
        db.session.commit()
        flash('Timeline entry deleted 🗑️', 'info')
        return redirect(url_for('admin_dashboard'))
    return render_template('confirm_delete.html', mode='timeline', item=t)


# ===== CLI helper =====
@app.cli.command('init-db')
def init_db():
    with app.app_context():
        db.create_all()
        print('Database created')


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
