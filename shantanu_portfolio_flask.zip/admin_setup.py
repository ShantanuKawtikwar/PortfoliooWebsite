from app import app, db
from models import AdminUser
from werkzeug.security import generate_password_hash

USERNAME = "Shantanukawtikwar27"
PASSWORD = "Prachi2711@$"

with app.app_context():
    db.create_all()
    existing = AdminUser.query.filter_by(username=USERNAME).first()
    if existing:
        print("Admin user already exists.")
    else:
        user = AdminUser(username=USERNAME, password_hash=generate_password_hash(PASSWORD))
        db.session.add(user)
        db.session.commit()
        print("Admin user created:")
        print("Username:", USERNAME)
